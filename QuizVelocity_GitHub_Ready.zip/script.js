const quizzes = {
  general: [
    { q: "What is the capital of Pakistan?", a: "Islamabad", options: ["Karachi", "Lahore", "Islamabad"] },
    { q: "Which is the largest continent?", a: "Asia", options: ["Europe", "Africa", "Asia"] },
    { q: "Who wrote the national anthem of Pakistan?", a: "Hafeez Jullundhri", options: ["Allama Iqbal", "Hafeez Jullundhri", "Faiz Ahmed Faiz"] }
  ],
  science: [
    { q: "What planet is known as the Red Planet?", a: "Mars", options: ["Earth", "Mars", "Jupiter"] },
    { q: "Water freezes at what temperature?", a: "0°C", options: ["100°C", "0°C", "50°C"] },
    { q: "What gas do plants absorb?", a: "Carbon Dioxide", options: ["Oxygen", "Carbon Dioxide", "Nitrogen"] }
  ],
  math: [
    { q: "What is 7 × 8?", a: "56", options: ["54", "56", "58"] },
    { q: "What is the square root of 64?", a: "8", options: ["6", "8", "10"] },
    { q: "Solve: 15 ÷ 3", a: "5", options: ["3", "5", "7"] }
  ]
};

let currentQuiz = [];
let quizIndex = 0;
let score = 0;

function startQuiz(subject) {
  currentQuiz = quizzes[subject];
  quizIndex = 0;
  score = 0;
  showQuestion();
}

function showQuestion() {
  const container = document.getElementById("quiz-container");
  if (quizIndex >= currentQuiz.length) {
    container.innerHTML = `<h3>You scored ${score} out of ${currentQuiz.length}</h3>`;
    return;
  }
  const q = currentQuiz[quizIndex];
  container.innerHTML = `<h3>${q.q}</h3>` +
    q.options.map(opt =>
      `<button onclick="checkAnswer('${opt}')">${opt}</button>`
    ).join("");
}

function checkAnswer(selected) {
  const correct = currentQuiz[quizIndex].a;
  if (selected === correct) score++;
  quizIndex++;
  showQuestion();
}